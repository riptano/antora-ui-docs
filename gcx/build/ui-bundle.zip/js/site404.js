;(function () {
  'use strict'

  var sidebar = document.querySelector('aside.toc.sidebar')
  if (!sidebar) return
  if (document.querySelector('body.-toc')) return sidebar.parentNode.removeChild(sidebar)
  var levels = parseInt(sidebar.dataset.levels || 2, 10)
  if (levels < 0) return

  var articleSelector = 'article.doc'
  var article = document.querySelector(articleSelector)
  var headingsSelector = []
  for (var level = 0; level <= levels; level++) {
    var headingSelector = [articleSelector]
    if (level) {
      for (var l = 1; l <= level; l++) headingSelector.push((l === 2 ? '.sectionbody>' : '') + '.sect' + l)
      headingSelector.push('h' + (level + 1) + '[id]')
    } else {
      headingSelector.push('h1[id].sect0')
    }
    headingsSelector.push(headingSelector.join('>'))
  }
  var headings = find(headingsSelector.join(','), article.parentNode)
  if (!headings.length) return sidebar.parentNode.removeChild(sidebar)

  var lastActiveFragment
  var links = {}
  var list = headings.reduce(function (accum, heading) {
    var link = document.createElement('a')
    link.textContent = heading.textContent
    links[(link.href = '#' + heading.id)] = link
    var listItem = document.createElement('li')
    listItem.dataset.level = parseInt(heading.nodeName.slice(1), 10) - 1
    listItem.appendChild(link)
    accum.appendChild(listItem)
    return accum
  }, document.createElement('ul'))

  var menu = sidebar.querySelector('.toc-menu')
  if (!menu) (menu = document.createElement('div')).className = 'toc-menu'

  var title = document.createElement('h3')
  title.textContent = sidebar.dataset.title || 'Contents'
  menu.appendChild(title)
  menu.appendChild(list)

  var startOfContent = !document.getElementById('toc') && article.querySelector('h1.page ~ :not(.is-before-toc)')
  if (startOfContent) {
    var embeddedToc = document.createElement('aside')
    embeddedToc.className = 'toc embedded'
    embeddedToc.appendChild(menu.cloneNode(true))
    startOfContent.parentNode.insertBefore(embeddedToc, startOfContent)
  }

  window.addEventListener('load', function () {
    onScroll()
    window.addEventListener('scroll', onScroll)
  })

  function onScroll () {
    var scrolledBy = window.pageYOffset
    var buffer = getNumericStyleVal(document.documentElement, 'fontSize') * 1.15
    var ceil = article.offsetTop
    if (scrolledBy && window.innerHeight + scrolledBy + 2 >= document.documentElement.scrollHeight) {
      lastActiveFragment = Array.isArray(lastActiveFragment) ? lastActiveFragment : Array(lastActiveFragment || 0)
      var activeFragments = []
      var lastIdx = headings.length - 1
      headings.forEach(function (heading, idx) {
        var fragment = '#' + heading.id
        if (idx === lastIdx || heading.getBoundingClientRect().top + getNumericStyleVal(heading, 'paddingTop') > ceil) {
          activeFragments.push(fragment)
          if (lastActiveFragment.indexOf(fragment) < 0) links[fragment].classList.add('is-active')
        } else if (~lastActiveFragment.indexOf(fragment)) {
          links[lastActiveFragment.shift()].classList.remove('is-active')
        }
      })
      list.scrollTop = list.scrollHeight - list.offsetHeight
      lastActiveFragment = activeFragments.length > 1 ? activeFragments : activeFragments[0]
      return
    }
    if (Array.isArray(lastActiveFragment)) {
      lastActiveFragment.forEach(function (fragment) {
        links[fragment].classList.remove('is-active')
      })
      lastActiveFragment = undefined
    }
    var activeFragment
    headings.some(function (heading) {
      if (heading.getBoundingClientRect().top + getNumericStyleVal(heading, 'paddingTop') - buffer > ceil) return true
      activeFragment = '#' + heading.id
    })
    if (activeFragment) {
      if (activeFragment === lastActiveFragment) return
      if (lastActiveFragment) links[lastActiveFragment].classList.remove('is-active')
      var activeLink = links[activeFragment]
      activeLink.classList.add('is-active')
      if (list.scrollHeight > list.offsetHeight) {
        list.scrollTop = Math.max(0, activeLink.offsetTop + activeLink.offsetHeight - list.offsetHeight)
      }
      lastActiveFragment = activeFragment
    } else if (lastActiveFragment) {
      links[lastActiveFragment].classList.remove('is-active')
      lastActiveFragment = undefined
    }
  }

  function find (selector, from) {
    return [].slice.call((from || document).querySelectorAll(selector))
  }

  function getNumericStyleVal (el, prop) {
    return parseFloat(window.getComputedStyle(el)[prop])
  }
})()

;
(function () {
  'use strict'

  //var article = document.querySelector('article.doc')
  //var toolbar = document.querySelector('.toolbar')

  function decodeFragment (hash) {
    return hash && (~hash.indexOf('%') ? decodeURIComponent(hash) : hash).slice(1)
  }

  /*function computePosition (el, sum) {
              return article.contains(el) ? computePosition(el.offsetParent, el.offsetTop + sum) : sum
            }*/

  function jumpToAnchor (e) {
    if (e) {
      if (e.altKey || e.ctrlKey) return
      window.location.hash = '#' + this.id
      e.preventDefault()
    }
    //window.scrollTo(0, computePosition(this, 0) - toolbar.getBoundingClientRect().bottom)
    var elementToScroll = document.getElementById('#' + this.id)
    if (elementToScroll) {
      elementToScroll.scrollIntoView({ block: 'start', behavior: 'smooth' })
    }
  }

  window.addEventListener('load', function jumpOnLoad (e) {
    var fragment, target
    if ((fragment = decodeFragment(window.location.hash)) && (target = document.getElementById(fragment))) {
      jumpToAnchor.bind(target)()
      setTimeout(jumpToAnchor.bind(target), 0)
    }
    window.removeEventListener('load', jumpOnLoad)
  })

  Array.prototype.slice.call(document.querySelectorAll('a[href^="#"]')).forEach(function (el) {
    var fragment, target
    if ((fragment = decodeFragment(el.hash)) && (target = document.getElementById(fragment))) {
      el.addEventListener('click', jumpToAnchor.bind(target))
    }
  })
})()

;(function () {
  'use strict'

  var toggle = document.querySelector('.page-versions .version-menu-toggle')
  if (!toggle) return

  var selector = document.querySelector('.page-versions')

  toggle.addEventListener('click', function (e) {
    selector.classList.toggle('is-active')
    e.stopPropagation() // trap event
  })

  document.documentElement.addEventListener('click', function () {
    selector.classList.remove('is-active')
  })
})()

;(function () {
  'use strict'

  var navbarBurger = document.querySelector('.navbar-burger')
  if (!navbarBurger) return
  navbarBurger.addEventListener('click', toggleNavbarMenu.bind(navbarBurger))

  function toggleNavbarMenu (e) {
    e.stopPropagation() // trap event
    document.documentElement.classList.toggle('is-clipped--navbar')
    this.classList.toggle('is-active')
    var menu = document.getElementById(this.dataset.target)
    if (menu.classList.toggle('is-active')) {
      menu.style.maxHeight = ''
      var expectedMaxHeight = window.innerHeight - Math.round(menu.getBoundingClientRect().top)
      var actualMaxHeight = parseInt(window.getComputedStyle(menu).maxHeight, 10)
      if (actualMaxHeight !== expectedMaxHeight) menu.style.maxHeight = expectedMaxHeight + 'px'
    }
  }
})()


;
(function () {
  'use strict'

  var CMD_RX = /^\$ (\S[^\\\n]*(\\\n(?!\$ )[^\\\n]*)*)(?=\n|$)/gm
  var LINE_CONTINUATION_RX = /( ) *\\\n *|\\\n( ?) */g
  var TRAILING_SPACE_RX = / +$/gm
    //var config = (document.getElementById('site-script') || { dataset: {} }).dataset

    ;
  [].slice.call(document.querySelectorAll('.doc pre.highlight, .doc .literalblock pre')).forEach(function (pre) {
    var code, language, lang, copy, toast, toolbox
    if (pre.classList.contains('highlight')) {
      code = pre.querySelector('code')
      if ((language = code.dataset.lang) && language !== 'console') {
        ;
        (lang = document.createElement('span')).className = 'source-lang'
        lang.appendChild(document.createTextNode(language))
      }
    } else if (pre.innerText.startsWith('$ ')) {
      var block = pre.parentNode.parentNode
      block.classList.remove('literalblock')
      block.classList.add('listingblock')
      pre.classList.add('highlightjs', 'highlight');
      (code = document.createElement('code')).className = 'language-console hljs'
      code.dataset.lang = 'console'
      code.appendChild(pre.firstChild)
      pre.appendChild(code)
    } else {
      return
    };
    (toolbox = document.createElement('div')).className = 'source-toolbox'
    if (lang) toolbox.appendChild(lang)
    if (window.navigator.clipboard) {
      ;
      (copy = document.createElement('button')).className = 'copy-button'
      copy.setAttribute('title', 'Copy to clipboard')
      var img = document.createElement('div')
      img.className = 'copy-icon'
      copy.appendChild(img);
      (toast = document.createElement('span')).className = 'copy-toast'
      toast.appendChild(document.createTextNode('Copied!'))
      copy.appendChild(toast)
      toolbox.appendChild(copy)
    }
    pre.appendChild(toolbox)
    if (copy) img.addEventListener('click', writeToClipboard.bind(copy, code))
  })

  function extractCommands (text) {
    var cmds = []
    var m
    while ((m = CMD_RX.exec(text))) cmds.push(m[1].replace(LINE_CONTINUATION_RX, '$1$2'))
    return cmds.join(' && ')
  }

  function writeToClipboard (code) {
    var text = code.innerText.replace(TRAILING_SPACE_RX, '')
    if (code.dataset.lang === 'console' && text.startsWith('$ ')) text = extractCommands(text)
    window.navigator.clipboard.writeText(text).then(
      function () {
        this.classList.add('clicked')
        this.offsetHeight // eslint-disable-line no-unused-expressions
        this.classList.remove('clicked')
      }.bind(this),
      function () {}
    )
  }
})()

/*
https://gitlab.com/antora/antora-ui-default/-/merge_requests/126/
Lightbox functionality: a user clicks on an image, and it will open full screen until user closes it again.

Supported functionality:

when lightbox is closed for all images:
 * if the image has a link, the standard behavior for hovering and clicking is unchanged.

when lightbox is closed for standard block image:
 * when hovering over image AND if original size of image is greater than displayed image,
   THEN change mouse pointer to pointer
   (works for both bitmap images the same way as for SVG images)
 * when clicking on image AND if original size of image is greater than displayed image, THEN open lightbox
   (works for both bitmap images the same way as for SVG images)

when lightbox is closed for inlined or interactive SVG image:
 * when hovering over image THEN change mouse pointer to pointer
 * when clicking on image THEN open lightbox

when lightbox is open for all images:
 * when user clicks on close icon, lightbox will close
 * when user presses Escape, lightbox will close
 * when user presses Tab to select the close button and presses Space or Enter, lightbox will close

when lightbox is opened for standard block image:
 * when user clicks enlarged image, lightbox will close

when lightbox is opened for interactive SVG:
 * when user clicks enlarged image AND if the SVG doesn't contain any hyperlinks, lightbox will close
 * when user clicks enlarged image AND if the SVG contain a hyperlinks AND the user clicks outside of a hyperlink,
   nothing happens (the lightbox will stay open)
 * when user clicks enlarged image AND if the SVG contains hyperlinks AND the user clicks on a hyperlink,
   the hyperlinks will work as before

when lightbox is opened for inlined SVG:
 * when user clicks on links included in the SVG, the hyperlinks will work as before
 * when user clicks outside of the links withing the SVG, the lightbox will close

 */

;(function () {
  'use strict'
  var lightbox
  var config = (document.getElementById('site-script') || { dataset: {} }).dataset
  var content

  function init () {
    if (!lightbox) {
      lightbox = document.createElement('div')
      lightbox.setAttribute('aria-modal', 'true')
      lightbox.className = 'modal'
      var closeLink = document.createElement('a')
      // set href to make it selectable with tab / assistive technologies
      closeLink.href = '#'
      closeLink.className = 'close'
      closeLink.setAttribute('title', 'Close lightbox')
      if (config.svgAs === 'svg') {
        var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
        svg.setAttribute('class', 'copy-icon')
        var use = document.createElementNS('http://www.w3.org/2000/svg', 'use')
        use.setAttribute('href', window.uiRootPath + '/img/octicons-16.svg#icon-x')
        svg.appendChild(use)
        closeLink.appendChild(svg)
      } else {
        // https://codepen.io/marianab/pen/gOPJOjJ
        let svgIcon = `<svg xmlns="http://www.w3.org/2000/svg" height="329pt" viewBox="0 0 329.26933 329" width="329pt">
          <path d="m194.800781 164.769531 128.210938-128.214843c8.34375-8.339844 8.34375-21.824219 
          0-30.164063-8.339844-8.339844-21.824219-8.339844-30.164063 0l-128.214844 
          128.214844-128.210937-128.214844c-8.34375-8.339844-21.824219-8.339844-30.164063 
          0-8.34375 8.339844-8.34375 21.824219 0 30.164063l128.210938 128.214843-128.210938 
          128.214844c-8.34375 8.339844-8.34375 21.824219 0 30.164063 4.15625 4.160156 9.621094 
          6.25 15.082032 6.25 5.460937 0 10.921875-2.089844 15.082031-6.25l128.210937-128.214844 
          128.214844 128.214844c4.160156 4.160156 9.621094 6.25 15.082032 6.25 5.460937 0 
          10.921874-2.089844 15.082031-6.25 8.34375-8.339844 8.34375-21.824219 0-30.164063zm0 0"/></svg>`
        var img = document.createElement('img')
        img.src=  `data:image/svg+xml;utf-8,${svgIcon}`
        img.alt = 'close icon'
        img.className = 'x-icon'
        closeLink.appendChild(img)
      }
      lightbox.appendChild(closeLink)
      content = document.createElement('div')
      content.className = 'content'
      lightbox.appendChild(content)
      var body = document.getElementsByTagName('body')[0]
      body.appendChild(lightbox)
      body.addEventListener('keydown', function (e) {
        if (e.code === 'Escape' && isOpen()) {
          close(e)
        }
      })

      content.addEventListener('click', close)
      closeLink.addEventListener('click', function (e) {
        close(e)
        e.preventDefault()
      })
      closeLink.addEventListener('keydown', function (e) {
        if (e.code === 'Space' || e.code === 'Enter') {
          close(e)
          e.preventDefault()
        }
      })
    }
  }

  function open () {
    lightbox.style.display = 'flex'
    document.body.style.overflow = 'hidden'
  }

  function isOpen () {
    return lightbox && lightbox.style.display === 'flex'
  }

  function close (e) {
    lightbox.style.display = 'none'
    content.firstChild.remove()
    document.body.style.overflow = ''
    // don't prevent default here, as that will allow links in SVGs to work
  }

  // depending on ratio of source vs target element, make the lightbox content 90% of height or width
  function setImageSize (img, source, target) {
    var ratioSource = source.offsetWidth / source.offsetHeight
    var ratioTarget = target.offsetWidth / target.offsetHeight
    if (ratioSource < ratioTarget) {
      img.style.height = '70vh'
    } else {
      img.style.width = '70vw'
    }
  }
  /* swiper slider img*/
  document.querySelectorAll('.slide img').forEach(function (element) {
    if (element.parentNode.nodeName === 'A') {
      // if parent node is an anchor, keep the anchor instead of opening lightbox
      return
    }
    element.parentNode.className += ' lightbox'
    if (typeof element.parentNode.classList.remove === 'function') {
      element.parentNode.addEventListener('mouseover', function (e) {
        if (element.naturalWidth <= element.offsetWidth && element.naturalHeight <= element.offsetHeight) {
          element.parentNode.classList.remove('lightbox')
        } else {
          element.parentNode.classList.add('lightbox')
        }
      })
    }
    element.style.cursor = 'pointer'
    element.addEventListener('click', function (e) {
      if (element.naturalWidth <= element.offsetWidth && element.naturalHeight <= element.offsetHeight) {
        // don't open lightbox is already shown at 100% or more
        return
      }
      init()
      var img = document.createElement('img')
      img.src = e.currentTarget.src
      img.alt = e.currentTarget.alt
      setImageSize(img, element.parentNode, content.parentNode)

      /* Render swiper
      let str = e.currentTarget.closest('.swiper').className
      let index = parseInt(str.match(/slider-(\d+)/i)[1]);
      content.appendChild(sliderBlock[index])*/
      content.appendChild(img)
      open()
    })
  })

  document.querySelectorAll('.imageblock img').forEach(function (element) {
    if (element.parentNode.nodeName === 'A') {
      // if parent node is an anchor, keep the anchor instead of opening lightbox
      return
    }
    element.parentNode.className += ' lightbox'
    if (typeof element.parentNode.classList.remove === 'function') {
      element.parentNode.addEventListener('mouseover', function (e) {
        if (element.naturalWidth <= element.offsetWidth && element.naturalHeight <= element.offsetHeight) {
          element.parentNode.classList.remove('lightbox')
        } else {
          element.parentNode.classList.add('lightbox')
        }
      })
    }
    element.addEventListener('click', function (e) {
      if (element.naturalWidth <= element.offsetWidth && element.naturalHeight <= element.offsetHeight) {
        // don't open lightbox is already shown at 100% or more
        return
      }
      init()
      var img = document.createElement('img')
      img.src = e.currentTarget.src
      img.alt = e.currentTarget.alt
      setImageSize(img, element.parentNode, content.parentNode)
      content.appendChild(img)
      open()
    })
  })

  document.querySelectorAll('.imageblock object').forEach(function (element) {
    if (element.parentNode.nodeName === 'A') {
      // if parent node is an anchor, keep the anchor instead of opening lightbox
      return
    }
    element.parentNode.className += ' lightbox'
    element.parentNode.addEventListener('click', function (e) {
      init()
      var img = document.createElement('object')
      img.type = element.type
      img.data = element.data
      open()
      setImageSize(img, element, content.parentNode)
      if (element.getSVGDocument() && element.getSVGDocument().querySelectorAll('a').length === 0) {
        // if the SVG doesn't contain any links, allow user to click on image to close the image
        img.style.pointerEvents = 'none'
      }
      content.appendChild(img)
      // prevent links in SVGs to open, as this should only open the lightbox
      e.preventDefault()
    })
  })
  document.querySelectorAll('.imageblock svg').forEach(function (element) {
    if (element.parentNode.nodeName === 'A') {
      // if parent node is an anchor, keep the anchor instead of opening lightbox
      return
    }
    element.parentNode.className += ' lightbox'
    element.parentNode.addEventListener('click', function (e) {
      init()
      var img = element.cloneNode(true)
      open()
      // override height/width from cloned element
      img.style.height = 'auto'
      img.style.width = 'auto'
      // need to select element's parent node, as offsetWidth/offsetHeight not available on SVG
      setImageSize(img, element.parentNode, content.parentNode)
      content.appendChild(img)
      // prevent links in SVGs to open, as this should only open the lightbox
      e.preventDefault()
    })
  })
})()